/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author DEll
 */
public class components {
    String hp, zone, outlet;
    public components(String hp, String zone, String outlet){
        this.hp = hp;
        this.zone = zone;
        this.outlet = outlet;
    }
    public void setZone(String zone) {
        this.zone = zone;
    }

    public void setOutlet(String outlet) {
        this.outlet = outlet;
    }

    public void setHp(String hp) {
        this.hp = hp;
    }

    public String getZone() {
        return zone;
    }

    public String getOutlet() {
        return outlet;
    }

    public String getHp() {
        return hp;
    }
}
